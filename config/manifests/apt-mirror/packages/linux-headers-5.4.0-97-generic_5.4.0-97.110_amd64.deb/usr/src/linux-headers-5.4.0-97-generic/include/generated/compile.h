/* This file is auto generated, version 110-Ubuntu */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#110-Ubuntu SMP Thu Jan 13 18:22:13 UTC 2022"
#define LINUX_COMPILE_BY "buildd"
#define LINUX_COMPILE_HOST "lcy02-amd64-032"
#define LINUX_COMPILER "gcc version 9.3.0 (Ubuntu 9.3.0-17ubuntu1~20.04)"
